



var curPage = 0;//判断当前页面是第几页
var maxPage;
var month = 0;	//月
$(function(){
	//isCurMonth();
	initPage(1);
})
function page(p){
	if(!isNaN(p)){	
		/*alert("是数字")*/
		if(curPage==p){
			return false;
		}
		curPage = p;
	}else{
		/*alert("是字符串")*/
		if(p=="home") curPage = 0;
		if(p=="pre")  curPage --;
		if(p=="next") curPage ++;
		if(p=="end")  curPage = maxPage-1;
	}
	if(curPage<0){
		curPage=0;
	}
	if(curPage==maxPage){
		curPage=maxPage-1;
	}
	initPage(curPage)
}
function initPage(p){
	//向后台请求数据 使用分页查询 将数据传递到前台,其中有最近的7个数值
	maxPage = 12;		//总页数
	var page = getPages();
	
	//p为当前页数
	pageState(page.split(","))
	
}



function pageState(page){
	$(".p_num").html("总&nbsp;"+maxPage+"&nbsp;页");
	
	
	
	var eles = $(".p1");
	$(eles).removeClass("p_select");
	for(var i = 0; i<eles.length; i++){
		if(i<page.length){
			if(curPage==page[i]){
				$(eles[i]).addClass("p_select");
			}
			$(eles[i]).text(parseInt(page[i])+1);
			$(eles[i]).attr("onclick","page("+page[i]+")")
		}else{
			$(eles[i]).hide();
		}
	}
}

/**
 * 对分页的参数判断，生成相应的字符串
 * @returns {String}
 */
function getPages(){
	//已知当前页	curPage		最大页面	maxPage		每页显示7页数	
	var str = "";
	if(maxPage>7&&curPage>=4){
		if(maxPage-curPage>3){
			for(var i = curPage-3; i<=curPage+3;i++) 	str = str+i+",";
		}else{
			for(var i = maxPage-7; i < maxPage;i++)	 str = str+i+",";
		}
	}else{
		for(var i = 0; i < maxPage;i++)	 str = str+i+",";
	}
	str = str.slice(0,-1)
	return str;		
}
function curMonth(){
	
}

function getInfor(){
	
	
}
